from samcli.commands.exceptions import UserException


class InvalidDocsCommandException(UserException):
    """
    Exception when the docs command fails
    """
