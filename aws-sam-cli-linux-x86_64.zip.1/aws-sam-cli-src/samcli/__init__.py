"""
SAM CLI version
"""

__version__ = "1.90.0"
